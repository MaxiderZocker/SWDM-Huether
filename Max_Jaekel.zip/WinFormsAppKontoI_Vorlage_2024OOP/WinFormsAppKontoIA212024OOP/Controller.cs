﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsAppKontoIA212024OOP
{
    class Controller
    {
        List<Konto> kontenListe;

        public Controller()
        {
            List<Konto> kontenListe = new List<Konto>();

        }
    }

}
